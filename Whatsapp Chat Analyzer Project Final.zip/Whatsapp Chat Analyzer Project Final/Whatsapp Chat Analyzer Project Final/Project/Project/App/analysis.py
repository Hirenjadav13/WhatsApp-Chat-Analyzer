import pandas as pd
import re
from datetime import datetime
import warnings
import plotly.express as px
from plotly.offline import plot
from collections import Counter
import emoji
import plotly.graph_objects as go
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import base64
import io

warnings.filterwarnings("ignore")

# Color theme
BAR_COLOR = "#25D366"       # WhatsApp green
LINE_COLOR = "#128C7E"      # WhatsApp dark green
BG_COLOR = "#f0f0f0"        # Light background
FONT_COLOR = "#075E54"      # Dark text
GRID_COLOR = "#d0d0d0"      # Light grid

def total_no_of_messages(df, user):
    return df.shape[0] if user == "Overall" else df[df["User"] == user].shape[0]

def total_no_of_word(df, user):
    words = []
    messages = df["Message"] if user == "Overall" else df[df["User"] == user]["Message"]
    for message in messages:
        words.extend(message.split())
    return len(words)

def total_no_media_file(df, user):
    media_row = df[df["Message"] == "<Media omitted>\n"]
    return media_row.shape[0] if user == "Overall" else media_row[media_row["User"] == user].shape[0]

def total_no_of_msg_with_url(df, user):
    url_regex = r"(http|https)://\S+"
    url_row = df[df["Message"].str.contains(url_regex)]
    return url_row.shape[0] if user == "Overall" else url_row[url_row["User"] == user].shape[0]

def top_five_user_table(df):
    top_df = df["User"].value_counts().reset_index().head(5)
    return top_df.rename(columns={"count": "MessageCount"})

def top_five_user_pie(df):
    top_df = df["User"].value_counts().reset_index().head(5)
    top_df = top_df.rename(columns={"count": "MessageCount"})
    pie_fig = px.pie(
        data_frame=top_df,
        names="User",
        values="MessageCount",
        title="Top 5 Users by Message Count",
    )
    return plot(pie_fig, output_type="div")

def top_five_user_bar(df):
    top_df = df["User"].value_counts().reset_index().head(5)
    top_df = top_df.rename(columns={"count": "MessageCount"})
    bar_fig = px.bar(
        data_frame=top_df,
        x="User",
        y="MessageCount",
        title="Top 5 Users by Message Count",
    )
    bar_fig.update_traces(marker=dict(color=BAR_COLOR))
    return plot(bar_fig, output_type="div")

def top_10_word(df, user):
    temp = df[df["User"] != "WhatApp Notification"]
    temp = temp[temp["Message"] != "<Media omitted>\n"]
    with open("app/stop_hinglish.txt", "r") as f:
        stop_word_hinglish = f.read()
    with open("app/stopwords_hindi.txt", "r", encoding="utf-8") as f:
        stop_word_hindi = f.read()
    stop_word = stop_word_hindi + stop_word_hinglish

    words = []
    messages = temp["Message"] if user == "Overall" else temp[temp["User"] == user]["Message"]
    for message in messages:
        for word in message.lower().split():
            if word not in stop_word:
                words.append(word)

    top_words_df = pd.DataFrame(Counter(words).most_common(10))
    return top_words_df.rename(columns={0: "Word", 1: "Frequency"})

def top_10_emoji(df, user):
    temp_df = df if user == "Overall" else df[df["User"] == user]
    words = []
    for message in temp_df["Message"]:
        for c in message:
            if emoji.is_emoji(c):
                words.append(c)
    top_emoji_df = pd.DataFrame(Counter(words).most_common(10))
    return top_emoji_df.rename(columns={0: "Emoji", 1: "Frequency"})

def year_wise_analysis(df, user):
    timeline_Year = df if user == "Overall" else df[df["User"] == user]
    timeline_Year = timeline_Year.groupby(["Year"]).count()["Message"].reset_index()

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=timeline_Year["Year"],
        y=timeline_Year["Message"],
        name="Messages",
        marker_color=BAR_COLOR,
        opacity=0.85
    ))
    fig.add_trace(go.Scatter(
        x=timeline_Year["Year"],
        y=timeline_Year["Message"],
        mode="lines+markers",
        name="Messages Trend",
        line=dict(color=LINE_COLOR, width=2),
        marker=dict(color=LINE_COLOR)
    ))
    fig.update_layout(
        title="Year Wise Analysis",
        plot_bgcolor=BG_COLOR,
        paper_bgcolor=BG_COLOR,
        font=dict(color=FONT_COLOR, size=14),
        xaxis=dict(title="Year", gridcolor=GRID_COLOR),
        yaxis=dict(title="Message Count", gridcolor=GRID_COLOR),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=LINE_COLOR))
    )
    return fig.to_html(full_html=False)

def day_wise_analysis(df, user):
    timeline = df if user == "Overall" else df[df["User"] == user]
    timeline["Day_Name"] = pd.to_datetime(timeline["DateTime"]).dt.day_name()
    day_counts = timeline["Day_Name"].value_counts().reindex([
        "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
    ]).fillna(0).astype(int)

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=day_counts.index,
        y=day_counts.values,
        name="Messages",
        marker_color=BAR_COLOR,
        opacity=0.85
    ))
    fig.add_trace(go.Scatter(
        x=day_counts.index,
        y=day_counts.values,
        mode="lines+markers",
        name="Messages Trend",
        line=dict(color=LINE_COLOR, width=2),
        marker=dict(color=LINE_COLOR)
    ))
    fig.update_layout(
        title="Day Wise Analysis",
        plot_bgcolor=BG_COLOR,
        paper_bgcolor=BG_COLOR,
        font=dict(color=FONT_COLOR, size=14),
        xaxis=dict(title="Day", gridcolor=GRID_COLOR),
        yaxis=dict(title="Message Count", gridcolor=GRID_COLOR),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=LINE_COLOR))
    )
    return fig.to_html(full_html=False)

def month_wise_analysis(df, user):
    timeline = df if user == "Overall" else df[df["User"] == user]
    timeline["Month"] = pd.to_datetime(timeline["DateTime"]).dt.strftime("%B")
    month_counts = timeline["Month"].value_counts().reindex([
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]).fillna(0).astype(int)

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=month_counts.index,
        y=month_counts.values,
        name="Messages",
        marker_color=BAR_COLOR,
        opacity=0.85
    ))
    fig.add_trace(go.Scatter(
        x=month_counts.index,
        y=month_counts.values,
        mode="lines+markers",
        name="Messages Trend",
        line=dict(color=LINE_COLOR, width=2),
        marker=dict(color=LINE_COLOR)
    ))
    fig.update_layout(
        title="Month Wise Analysis",
        plot_bgcolor=BG_COLOR,
        paper_bgcolor=BG_COLOR,
        font=dict(color=FONT_COLOR, size=14),
        xaxis=dict(title="Month", gridcolor=GRID_COLOR),
        yaxis=dict(title="Message Count", gridcolor=GRID_COLOR),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=LINE_COLOR))
    )
    return fig.to_html(full_html=False)

def word_cloud(df, user):
    temp = df[df["User"] != "WhatApp Notification"]
    temp = temp[temp["Message"] != "<Media omitted>\n"]
    with open("app/stop_hinglish.txt", "r") as f:
        stop_word_hinglish = f.read()
    with open("app/stopwords_hindi.txt", "r", encoding="utf-8") as f:
        stop_word_hindi = f.read()
    stop_word = stop_word_hindi + stop_word_hinglish

    words = []
    messages = temp["Message"] if user == "Overall" else temp[temp["User"] == user]["Message"]
    for message in messages:
        for word in message.lower().split():
            if word not in stop_word:
                words.append(word)

    words_freq = dict(Counter(words).items())
    try:
        wordcloud = WordCloud(width=570, height=400, background_color="white", max_words=20).generate_from_frequencies(words_freq)
        img_data = io.BytesIO()
        wordcloud.to_image().save(img_data, format="PNG")
        img_data.seek(0)
        img_base64 = base64.b64encode(img_data.getvalue()).decode()
        return f'<img src="data:image/png;base64,{img_base64}" alt="Word Cloud">'
    except:
        return "<p>Unable to generate word cloud.</p>"
