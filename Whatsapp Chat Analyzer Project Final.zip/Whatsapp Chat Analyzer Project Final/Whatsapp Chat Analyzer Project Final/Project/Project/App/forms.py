from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User

class LoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'login__input',
            'placeholder': 'Username',
        }),
        label="Username"
    )

    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'login__input',
        'placeholder': 'Password',
    }))

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        'class': 'login__input',
        'placeholder': 'Email ID',
    }))
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'login__input',
        'placeholder': 'Username',
    }))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'login__input',
        'placeholder': 'Password',
    }))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'login__input',
        'placeholder': 'Confirm Password',
    }))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']