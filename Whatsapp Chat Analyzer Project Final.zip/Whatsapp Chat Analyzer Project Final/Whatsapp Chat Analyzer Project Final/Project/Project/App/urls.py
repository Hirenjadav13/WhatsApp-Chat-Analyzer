from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('home/',views.home_view,name='home'),
    path('', views.login_view ,name='login'),
    path('logout/', views.logout_view ,name='logout'),
    path('register/', views.register_view, name='register'),
    path('about/',views.about_view,name='about'),
    path('project/',views.project_view,name='project'),
    path('stats',views.stats,name='stats')
]
