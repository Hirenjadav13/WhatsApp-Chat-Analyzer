from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import LoginForm, RegisterForm
import pandas as pd
import json
from django.http import HttpResponse
from .text_df import what_app_chat_to_data_frame
from .analysis import *
import plotly.express as px
from plotly.offline import plot
from django.contrib import messages


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')  # ✅ Use username
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)  # ✅ Use username here too
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, "Invalid username or password")
    else:
        form = LoginForm()
    return render(request, 'App/login.html', {'form': form})


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            # Add success message
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')  # Redirect to login page instead of auto-login
    else:
        form = RegisterForm()
    return render(request, 'App/register.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home_view(request):
    return render(request, 'App/home.html')

def about_view(request):
    return render(request,'App/about.html')

def project_view(request):
    if request.method == "POST" and request.FILES.get("file"):
        file = request.FILES["file"]
        data = file.read().decode("utf-8")
        df = what_app_chat_to_data_frame(data)
        if df is not None:
            # Convert Timestamp objects to string before storing in session
            df["DateTime"] = df["DateTime"].astype(str)
            request.session["csv_data"] = json.dumps(df.to_dict())
            return redirect("stats")
        else:
            return HttpResponse("Error processing data. Please check the input format.")
    return render(request, "App/project.html")

def stats(request):
    csv_data = request.session.get("csv_data")

    if csv_data is None:
        messages.error(request, "Session expired or no file uploaded. Please upload the WhatsApp chat file again.")
        return redirect("index")

    try:
        df = pd.DataFrame.from_dict(json.loads(csv_data))
    except Exception as e:
        return HttpResponse(f"Error loading data: {e}")

    user_lst = df["User"].unique().tolist()

    if "WhatApp Notification" in user_lst:
        user_lst.remove("WhatApp Notification")

    user_lst.sort()
    user_lst.insert(0, "Overall")

    if request.method == "POST" and "username" in request.POST:
        username = request.POST["username"]
    else:
        username = "Overall"

    # Shared metrics
    msg = total_no_of_messages(df, username)
    word = total_no_of_word(df, username)
    media = total_no_media_file(df, username)
    link = total_no_of_msg_with_url(df, username)
    top_word = top_10_word(df, username)
    top_emoji = top_10_emoji(df, username)
    year = year_wise_analysis(df, username)
    month = month_wise_analysis(df, username)
    day = day_wise_analysis(df, username)
    word_cloud_img = word_cloud(df, username)

    # Data for "Overall" view
    if username == "Overall":
        top_user = top_five_user_table(df)
        top_user_bar = top_five_user_bar(df)
        top_user_pie = top_five_user_pie(df)
        return render(
            request,
            "App/statistics.html",
            {
                "unique_users": user_lst,
                "username": username,
                "msg": msg,
                "word": word,
                "media": media,
                "link": link,
                "top_user": top_user.to_html(classes="table table-striped"),
                "top_user_bar": top_user_bar,
                "top_user_pie": top_user_pie,
                "top_word": top_word.to_html(classes="table table-striped"),
                "top_emoji": top_emoji.to_html(classes="table table-striped"),
                "year": year,
                "month": month,
                "day": day,
                "word_cloud": word_cloud_img,
            },
        )
    else:
        return render(
            request,
            "App/statistics.html",
            {
                "unique_users": user_lst,
                "username": username,
                "msg": msg,
                "word": word,
                "media": media,
                "link": link,
                "top_word": top_word.to_html(classes="table table-striped"),
                "top_emoji": top_emoji.to_html(classes="table table-striped"),
                "year": year,
                "month": month,
                "day": day,
                "word_cloud": word_cloud_img,
            },
        )